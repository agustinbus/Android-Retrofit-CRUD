package com.example.chhaichivon.crud_retrofit.utils;

import java.util.Date;

/**
 * Created by chhaichivon on 6/22/17.
 */

public class DateConvertor {

	public static Date convertDateJsonDatabase(Date date){
		Date dateReturn = new Date();


		return  dateReturn;
	}
}
